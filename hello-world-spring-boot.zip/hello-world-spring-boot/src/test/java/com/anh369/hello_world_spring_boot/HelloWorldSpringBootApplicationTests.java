package com.anh369.hello_world_spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWorldSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
